<!--firstPage.php-->
<?php
  session_start();
  echo "<HTML><BODY>";
  $_SESSION["nome"]="teo";
?>
<A href="secondPage.php"> second page</A>
</BODY></HTML>
