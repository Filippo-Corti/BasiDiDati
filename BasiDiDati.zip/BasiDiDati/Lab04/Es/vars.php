<?php
$connection_str = "host=localhost port=5432 dbname=test user=postgres password=dbadmin";
?>
