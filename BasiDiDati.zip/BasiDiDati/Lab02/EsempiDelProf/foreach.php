<!--foreach.php-->
<?php
$arr=array("one","two","three");
foreach ($arr as $key => $value) 
{
	echo "Key: " . $key . " ";
	echo "Value: ".$value."<br>";
}
?>
