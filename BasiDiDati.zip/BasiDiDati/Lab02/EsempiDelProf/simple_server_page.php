<!--simple_server_page.php-->
<!DOCTYPE html>
<html>

<head>
	<title>Test PHP</title>
</head>

<body>
  <?php echo "<p> Hello World! </p>"; ?>
</body>

</html>