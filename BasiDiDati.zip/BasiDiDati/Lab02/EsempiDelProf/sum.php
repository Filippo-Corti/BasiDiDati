<!--sum.php-->
<?php 
$a=1;
$b=2;
function Sum()
{
  global $a, $b;
  $b=$a+$b;
}
Sum();
echo $b;
?>