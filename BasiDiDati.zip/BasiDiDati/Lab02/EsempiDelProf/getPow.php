<!--getPow.php-->
<?php
function getPow($base, $esp)
{
	return $base ** $esp;
}
print getPow(5,3);
?>