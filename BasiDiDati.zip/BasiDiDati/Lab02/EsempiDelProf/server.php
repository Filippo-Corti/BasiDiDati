<!--server.php-->
<?php 
echo $_SERVER['SERVER_NAME']."<br>"; 
echo  $_SERVER['HTTP_HOST'];
  //var_dump($_SERVER);
  //print($_SERVER);
?>