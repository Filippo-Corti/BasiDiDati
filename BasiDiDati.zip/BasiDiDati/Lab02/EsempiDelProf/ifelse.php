<!--ifelse.php-->
<?php 
	$d=date("D"); 
	echo $d.'</br>';
	if ($d=="Fri")
		echo "Have a nice weekend!";
    else
		echo "Have a nice day!"; 
?>
