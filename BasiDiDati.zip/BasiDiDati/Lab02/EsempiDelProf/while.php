<!--while.php-->
<?php
$i=5;
while($i<5)
{
  echo "The number is ".$i."<br>";
  $i++;
}
?>
