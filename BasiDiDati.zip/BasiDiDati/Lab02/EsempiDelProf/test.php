<!--test.php-->
<?php
  phpinfo();
?>