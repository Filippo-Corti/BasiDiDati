<!--scope_static.php-->
<?php
function test(){
  static $a=0;
  echo $a;
  $a++;
}
test();
test();
?>