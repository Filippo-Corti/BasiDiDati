<!--dowhile.php-->
<?php
$i=10;
do
{
  echo "The number is ".$i."<br>";
  $i++;
} while($i<5);
?>