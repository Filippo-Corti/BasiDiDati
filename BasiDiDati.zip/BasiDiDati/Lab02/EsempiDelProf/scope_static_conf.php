<!--scope_static_conf-->
<?php
function test(){
  $a=0;
  echo $a;
  $a++;
}
test();
test();
?>